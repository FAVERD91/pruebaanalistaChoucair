package co.com.choucair.certification.pruebaanalista.userinterface;

import net.serenitybdd.screenplay.targets.Target;

public class Location {
    public static final Target BUTTONLOCATION = Target.the("Button Next Step").locatedBy("//a[@aria-label=\"Next step - select your devices\"]");
}
