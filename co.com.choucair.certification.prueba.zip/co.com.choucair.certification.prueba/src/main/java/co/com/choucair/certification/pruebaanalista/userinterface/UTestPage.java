package co.com.choucair.certification.pruebaanalista.userinterface;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl("https://www.utest.com")
public class UTestPage extends PageObject {
}
